import React from "react";

const Old = () => {
  return (
    <>
      <Container fluid="md">
        <CardGroup>
          <Card>
            <Card.Body>
              <Card.Title>
                <h5>Made In Love With DashNinja..</h5>
              </Card.Title>
            </Card.Body>
          </Card>
        </CardGroup>
        <br />
        <Container className="container-fluid p-5 formContainer">
          {/* <!-- Comments Start --> */}
          <h3 className="card-title mt-5 mb-4 comment text-white font-weight-bold">
            LEAVE A COMMENT
          </h3>
          <div className="needs-validation" id="myform">
            <div className="form-row">
              {/* <!-- FirstName --> */}
              <div className="col-lg-4 mb-3">
                <input
                  type="FirstName"
                  className="form-control p-4 rounded-0 inputField border-0"
                  placeholder="First Name"
                  id="firstname"
                />
              </div>
              {/* <!-- Middle Name --> */}
              <div className="col-lg-4 mb-3">
                <input
                  type="text"
                  className="form-control p-4 rounded-0 inputField border-0"
                  placeholder="Middle Name"
                />
              </div>
              {/* <!-- Last Name --> */}
              <div className="col-lg-4 mb-3">
                <input
                  type="text"
                  className="form-control p-4 rounded-0 inputField border-0"
                  placeholder="Last Name"
                  id="lastname"
                />
              </div>
              {/* <!-- PhoneNumber --> */}
              <div className="col-lg-4 mb-3">
                <input
                  type="tel"
                  className="form-control p-4 rounded-0 inputField border-0"
                  placeholder="PhoneNumber"
                  id="phonenumber"
                  maxlength="10"
                />
              </div>
              {/* <!-- EmailAddress --> */}
              <div className="col-lg-4 mb-3">
                <input
                  type="email"
                  className="form-control p-4 rounded-0 inputField border-0"
                  placeholder="EMAIL ADDRESS"
                  id="email"
                />
              </div>
              {/* <!-- DOB --> */}
              <div className="col-lg-4 mb-3">
                <input
                  type="date"
                  className="form-control p-4 rounded-0 inputField border-0"
                  placeholder="Date of Birth"
                  id="dob"
                />
              </div>
              {/* <!-- Gender --> */}
              <div className="col-lg-4 mb-3">
                <select
                  name="Gender"
                  id="gender"
                  className="container-fluid p-3  customSelect"
                >
                  <option value="">Gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Others">Others</option>
                </select>
              </div>
            </div>
            <div className="row">
              <div className="col-lg-6 ">
                <button
                  className="btn mt-4 rounded-2 p-3 pl-4 pr-4 submitButton text-white font-weight-bold"
                  type="submit"
                  id="submit"
                >
                  SUBMIT DATA
                </button>
              </div>
              {/* <!-- <div className="col-lg-6 ">
            <button className="btn mt-4 rounded-2 p-3 pl-4 pr-4 submitButton text-white font-weight-bold float-right"
              type="submit">
              CLEAR DATA
            </button>
          </div> --> */}
            </div>
          </div>
        </Container>
      </Container>
    </>
  );
};

export default Old;
