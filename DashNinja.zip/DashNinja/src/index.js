import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
import "bootstrap/dist/css/bootstrap.min.css";

import Layout from "./Layout";
import "./index.css";
ReactDOM.render(
  <>
    <Layout>
      <App />
    </Layout>
  </>,
  document.getElementById("root")
);
