import { useState } from "react";
import { Button, Card, Container, Row } from "react-bootstrap";

import CardHeader from "./Components/CardHeader";
import FormContainer from "./Form";

const App = () => {
  const [data, incomingData] = useState([]);

  const incomingDataHandler = (enteredData) => {
    incomingData((prev) => [...prev, enteredData]);
    var newData = [...data, enteredData];
    localStorage.setItem("Data", JSON.stringify(newData));
  };

  const clearDataHandler = (e) => {
    e.preventDefault();
    localStorage.removeItem("Data");
    incomingData([]);
  };

  const consoleData = JSON.parse(localStorage.getItem("Data"));

  console.log(consoleData);

  const editHandler = () => {
    console.log("Edit Button Clicked");
    alert("Edit Feature has not yet been enabled. Thank You");
  };

  return (
    <>
      <Container fluid="md">
        {/* CardContainer */}
        <CardHeader />
        <Container>
          <Row>
            <Container fluid className="p-2 formContainer">
              {/* FormContainer */}
              <FormContainer
                incomingDataHandler={incomingDataHandler}
                clearDataHandler={clearDataHandler}
              />
            </Container>
          </Row>
        </Container>
        <Container>
          {/* Render UI FROM LocalStorage */}
          {consoleData === null ? (
            ""
          ) : (
            <>
              {consoleData.map((i) => {
                const {
                  Dob,
                  Email,
                  FirstName,
                  Gender,
                  LastName,
                  PhoneNumber,
                  id,
                } = i;
                return (
                  <Card
                    key={id}
                    className="mt-3 mb-3 text-white p-2 border-0 rounded-0 comment"
                  >
                    <Card.Body>
                      <Card.Link>
                        <Button
                          type="Button"
                          style={{ float: "right" }}
                          onClick={editHandler}
                        >
                          Edit
                        </Button>
                      </Card.Link>
                      <Card.Title>
                        Name: {FirstName} {LastName}
                      </Card.Title>
                      <Card.Title>Email: {Email}</Card.Title>
                      <Card.Title>Gender: {Gender}</Card.Title>
                      <Card.Title>Date Of Birth: {Dob}</Card.Title>
                      <Card.Title>PhoneNumber: {PhoneNumber}</Card.Title>
                    </Card.Body>
                  </Card>
                );
              })}
            </>
          )}
        </Container>
      </Container>
    </>
  );
};

export default App;
