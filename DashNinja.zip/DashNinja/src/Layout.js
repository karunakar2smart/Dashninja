import React from "react";
import { Container } from "react-bootstrap";
// import "./index.css";

const Layout = (props) => {
  return (
    <>
      <Container fluid className="vh-100 ">
        {props.children}
      </Container>
    </>
  );
};

export default Layout;
