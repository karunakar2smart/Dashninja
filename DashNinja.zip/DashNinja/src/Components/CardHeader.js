import React from "react";
import { Card } from "react-bootstrap";

const CardHeader = () => {
  return (
    <>
      <Card className="rounded-0  mt-4 mb-4 headerCard">
        <Card.Body>
          <Card.Title className="text-dark text-center">
            Made in Love with DashNinja
          </Card.Title>
        </Card.Body>
      </Card>
    </>
  );
};

export default CardHeader;
